<?php
@error_reporting(0);
header('Content-Type: text/html; charset=UTF-8');

function hashFindFile($file)
{
  if($file)
  {
    if(file_exists('sessions/'.$file))
    {
      return filemtime('sessions/'.$file); // Return file creation time
    }
    return false;
  }
  return false;
}


$access = stripslashes($_GET['access']);
$login  = stripslashes($_GET['login']);
$action = stripslashes($_REQUEST['action']);


if($login)
{
  require_once('php/hash.php');
  exit;
}

if($access)
{
  if(hashFindFile($access))
  {
    $expires = time() - hashFindFile($access);
    if($expires > 3600)
    {
      echo 'Session has expired!';
    }
    else
    {
      header("Location: elfinder.php?access=$access");
    }
  }

  else
  {
    echo 'Session not exists!';
  }
  exit;

}

if($action == 'ping')
{
  echo 'OK';
  exit;
}

elseif($action == 'login')
{
  if(chk_login($unm = strtolower(trim($_REQUEST['unm'])),trim($_REQUEST['pwd']),trim($_REQUEST['pwd_afm'])))
  {
    $fnm = $_SERVER['REMOTE_ADDR'].'_www.an56.org_'.md5($unm.'_'.strtotime(date('Y-m-d')));
    file_put_contents('sessions/'.$fnm,'');
    header("Location: index.php?access=$fnm");
  }
  else die("<script>alert('登录失败');location.href='?';</script>");
}

?>
<!DOCTYPE html>
<html lang="zh-cmn-Hans">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>File Manager For An56.org</title>
<link rel="stylesheet" href="//cdn.bootcss.com/bootstrap/3.3.5/css/bootstrap.min.css" charset="utf-8">
<link rel="stylesheet" href="//cdn.bootcss.com/bootstrap/3.3.5/css/bootstrap-theme.min.css" charset="utf-8">
<style>
body { margin:0; padding-top:10px; font-family:微软雅黑; }
.cf {*zoom:1;}
.cf:before,.cf:after {display:table;line-height:0;content:"";}
.cf:after {clear:both;}
.cl { clear:both; }
.fl { float:left; }
.fr { float:right; }
.btn-group.btn-inline { font-size:0; }
.btn-group.btn-inline > .btn,
.btn-group.btn-inline > .btn-group { float:none; }
td:last-child .dropdown-menu { left:auto; right:0; min-width:inherit; }
.panel .pagination { margin:0; }
.an-loading { position:fixed; bottom:20px; right:20px; float:left; display-:none; color:#888; }
.login-form { max-width:400px; margin-top:100px; }
.ad-gg-hide { position:relative; }
.ad-gg-hide .ad-gg-hide-box { position:absolute; top:0; left:0; width:720px; }
.ad-gg-hide ins,.ad-gg-hide iframe { margin:0 auto; text-align:center; opacity:.01; filter:alpha(opacity=1); filter:progid:DXImageTransform.Microsoft.Alpha(Opacity=1); }
.ad-gg-hide a,.ad-gg-hide img,.ad-gg-hide input,.ad-gg-hide label { position:relative; z-index:99; }
</style>
<script>var isIE = 0;</script>
<!--[if IE 9]><script>isIE = 9;</script><![endif]-->
<!--[if IE 8]><script>isIE = 8;</script><![endif]-->
<!--[if IE 7]><script>isIE = 7;</script><![endif]-->
<!--[if lt IE 7]><script>isIE = 6;</script><![endif]-->
<script>
window['App'] =
{
  name:'An56.org'
};
</script>
</head>
<body>
<div id="doc">
  <div class="container-fluid">
    <div class="login-form center-block ad-gg-hide">
      <div class="ad-gg-hide-box">
        <ins class="adsbygoogle"
             style="display:inline-block;width:336px;height:280px;"
             data-ad-client="ca-pub-0792299440404407"
             data-ad-slot="7772129546"></ins>
        <ins class="adsbygoogle"
             style="display:inline-block;width:336px;height:280px;"
             data-ad-client="ca-pub-0792299440404407"
             data-ad-slot="7772129546"></ins>
      </div>
      <form action="#?action=login" method="POST">
        <div class="form-group">
          <label>UserName</label>
          <input type="text" name="unm" class="form-control" placeholder="User or Email">
        </div>
        <div class="form-group">
          <label>Password</label>
          <input type="password" name="pwd" class="form-control" placeholder="Password">
        </div>
        <div class="form-group">
          <label>Management Password</label>
          <input type="password" name="pwd_afm" class="form-control" placeholder="文件管理器密码，第一次使用请在此设置，设置后不可更改">
        </div>
        <div class="btn-group pull-right" role="group">
          <a href="http://www.an56.org/" target="_blank" class="btn btn-default">安安免费空间</a>
        </div>
        <input type="submit" value="Submit" class="btn btn-default">
      </form>
    </div>
  </div>
</div>

<div class="an-loading"><i class="icon-spinner icon-spin icon-3x"></i></div>
<script>window.jQuery || document.write('<script src="http://libs.baidu.com/jquery/1.11.1/jquery.min.js" charset="utf-8">\x3C/script>');</script>
<script>window.jQuery || document.write('<script src="http://libs.useso.com/js/jquery/1.11.1/jquery.min.js" charset="utf-8">\x3C/script>');</script>
<script>window.jQuery || document.write('<script src="http://code.jquery.com/jquery.min.js" charset="utf-8">\x3C/script>');</script>
<script src="//cdn.bootcss.com/bootstrap/3.3.5/js/bootstrap.min.js" charset="utf-8"></script>
<link rel="stylesheet" href="http://libs.useso.com/js/font-awesome/3.2.1/css/font-awesome.min.css" charset="utf-8">
<!--[if IE 7]>
<link rel="stylesheet" href="http://libs.useso.com/js/font-awesome/3.2.1/css/font-awesome-ie7.min.css" charset="utf-8">
<![endif]-->
<style>
@font-face
{
  font-family: 'iconfont-10';
  src:url('http://at.alicdn.com/t/font_1401158182_6869004.eot'); /* IE9 */
  src:url('http://at.alicdn.com/t/font_1401158182_6869004.eot?#iefix') format('embedded-opentype'), /* IE6-IE8 */
  url('http://at.alicdn.com/t/font_1401158182_6869004.woff') format('woff'), /* chrome、firefox */
  url('http://at.alicdn.com/t/font_1401158182_6869004.ttf') format('truetype'), /* chrome、firefox、opera、Safari, Android, iOS 4.2+ */
  url('http://at.alicdn.com/t/font_1401158182_6869004.svg#iconfont') format('svg'); /* iOS 4.1- */
}
.iconfont { -webkit-font-smoothing:antialiased;-webkit-text-stroke-width:.2px;-moz-osx-font-smoothing:grayscale; }
.iconfont-10 { font-family:'iconfont-10' !important;font-style:normal;-webkit-font-smoothing:antialiased;-webkit-text-stroke-width:.2px;-moz-osx-font-smoothing:grayscale; }
</style>
<script>
window['jQuery'](function($)
{
//JQ
  window.body = $('body:first');
  $('.an-loading').hide(2000);
  (function()
  {
    window.body && $('.ad-gg-hide-box').length && body.has('.adsbygoogle') && body.find('form[action^="#"]').attr('action',function()
    {
      return $.trim($(this).attr('action')).replace(/^#/,'');
    });
  })();
//JQ
});
</script>
<script src="http://www.an56.net/js/an56.org.js" charset="utf-8"></script>
</body>
</html>
<?php

function chk_login($unm,$pwd,$pwd_afm = '')
{
  $fmp = trim(@file_get_contents('sessions/www.an56.org') ?: '');
  if($fmp == '' && $pwd_afm) file_put_contents('sessions/www.an56.org',encrypt_password($pwd_afm));
  elseif($fmp != encrypt_password($pwd_afm)) return false;
  $dat = array(
    'email'    => $unm,
    'password' => $pwd,
  );
  //$ret = anhttp('http://cpanel.an56.org/auth',$dat,'POST',$rqhead);
  $url = 'http://getapi.sinaapp.com/http/?method=POST&url=http%3A%2F%2Fcpanel.an56.org%2Fauth&data='.urlencode(http_build_query($dat));
  $ret = anhttp($url);
  //die(json_encode(['unm' => $unm,'pwd' => $pwd,$dat,http_build_query($dat),$ret]));
  return !preg_match('/login_password/i',$ret) || preg_match('/\/switcher/i',$ret);
}

function encrypt_password($pwd = '')
{
  return md5($pwd.'@an56.org');
}

function anhttp($url,$data = '',$method = 'GET',$rqhead = array())
{
  $mat = parse_urls($url);
  $host = $mat['host'];
  is_array($data) && $data = http_build_query($data);
  $header = 'Host: '.$host."\r\n";
  foreach($rqhead as $k => $v)
  {
    if(trim($v)) $header .= $k.': '.$v."\r\n";
  }
  if(in_array($method,array('POST','HEAD','PUT','TRACE','OPTIONS','DELETE')))
  {
    isset($rqhead['Content-Type'])   || $header .= 'Content-Type: application/x-www-form-urlencoded'."\r\n";
    isset($rqhead['Content-Length']) || $header .= 'Content-Length: '.strlen($data)."\r\n";
    $context = array(
      'http' => array(
        'method'  => $method,
        'header'  => $header,
        'content' => $data,
        'timeout' => 6000
      )
    );
  }
  else
  {
    if($data != '') $url .= (stristr($url,'?') ? '&' : '?').$data;
    $context = array(
      'http' => array(
        'method'  => 'GET',
        'header'  => $header,
        'timeout' => 6000
      )
    );
  }
  $stream_context = stream_context_create($context);
  $rb = file_get_contents($url,FALSE,$stream_context);
  return $rb;
}

function parse_urls($url = '')
{
  $arr = array();
  if($url)
  {
    $reg = '/\s*(?<href>(?<protocol>(?<scheme>[^:\/?#]+):)?(?<slashes>\/\/)?(?<authority>(?:(?<username>(?<user>[^:@\/?#]+))(?::(?<password>(?<pass>[^@]*)))?@)?(?<host>(?<domain>\[[^\]]+\]|[^:\/\\\?#\']+)(?::(?<port>\d+))?))?(?<pathname>(?<path>\/[^?#]*))?(?<search>\?(?<query>[^#]*))?(?<hash>#(?<fragment>.*))?)\s*/isu';
    preg_match($reg,$url,$arr);
  }
  return $arr;
}